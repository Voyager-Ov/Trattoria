(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_96ad801a._.js",
  "static/chunks/node_modules_208d0155._.js"
],
    source: "dynamic"
});
