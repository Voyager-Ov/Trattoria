(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_11db370e._.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_b45f2044._.js",
  "static/chunks/node_modules_fbd79c62._.js"
],
    source: "dynamic"
});
