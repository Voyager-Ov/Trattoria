(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_fc26ff26._.js",
  "static/chunks/node_modules_db8b5c1d._.js"
],
    source: "dynamic"
});
