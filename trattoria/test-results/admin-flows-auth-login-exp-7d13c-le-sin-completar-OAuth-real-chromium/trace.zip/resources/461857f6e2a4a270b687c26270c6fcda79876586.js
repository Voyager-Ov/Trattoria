(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_035fa492._.js",
  "static/chunks/node_modules_@radix-ui_07faa28c._.js",
  "static/chunks/node_modules_next_84cfa940._.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_b45f2044._.js",
  "static/chunks/node_modules_e4413146._.js"
],
    source: "dynamic"
});
