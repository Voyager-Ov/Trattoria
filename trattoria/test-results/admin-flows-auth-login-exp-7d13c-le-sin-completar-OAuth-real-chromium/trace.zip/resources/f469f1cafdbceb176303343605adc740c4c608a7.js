(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ui/badge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Badge",
    ()=>Badge,
    "badgeVariants",
    ()=>badgeVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
            success: "border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-200/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/badge.tsx",
        lineNumber: 34,
        columnNumber: 9
    }, this);
}
_c = Badge;
;
var _c;
__turbopack_context__.k.register(_c, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DashboardMetricCard",
    ()=>DashboardMetricCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/pencil.js [app-client] (ecmascript) <export default as Pencil>");
;
;
;
;
function DashboardMetricCard({ title, value, change, description, headerColor, icon, monthlyGoal, isPrimary = false }) {
    if (isPrimary) {
        if (monthlyGoal) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-zinc-900 rounded-[2rem] border-none shadow-xl shadow-zinc-200 overflow-hidden flex flex-col h-full group hover:bg-zinc-800 transition-all duration-300 relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-12 bg-white/10 flex items-center px-6 text-white/80 font-medium text-sm relative z-10",
                        children: [
                            title,
                            icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ml-auto text-white/60 flex items-center gap-3",
                                children: [
                                    icon,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/admin/dashboard/configuracion?tab=goals",
                                        className: "hover:text-white transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__["Pencil"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                            lineNumber: 42,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                        lineNumber: 41,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 39,
                                columnNumber: 34
                            }, this),
                            !icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ml-auto",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/admin/dashboard/configuracion?tab=goals",
                                    className: "text-white/60 hover:text-white transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__["Pencil"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                        lineNumber: 48,
                                        columnNumber: 37
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                    lineNumber: 47,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 46,
                                columnNumber: 29
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                        lineNumber: 37,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-6 flex flex-col justify-between flex-grow space-y-4 relative z-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-end gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-4xl font-bold text-white tracking-tight",
                                                children: [
                                                    monthlyGoal.progress,
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                                lineNumber: 56,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white/40 text-sm font-medium uppercase tracking-wider mb-1",
                                                children: monthlyGoal.type === "revenue" ? "Ingresos" : "Ganancia"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                                lineNumber: 57,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                        lineNumber: 55,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-emerald-400 text-sm font-bold tracking-wider",
                                        children: [
                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatCurrency"])(monthlyGoal.currentAmount),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white/30 truncate ml-1 font-medium",
                                                children: [
                                                    "/ ",
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatCurrency"])(monthlyGoal.amount)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                                lineNumber: 63,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                        lineNumber: 61,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 54,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-white/10 rounded-full h-3 overflow-hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-emerald-500 h-full rounded-full transition-all duration-1000",
                                    style: {
                                        width: `${monthlyGoal.progress}%`
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                    lineNumber: 67,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 66,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                        lineNumber: 53,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                lineNumber: 36,
                columnNumber: 17
            }, this);
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-zinc-900 rounded-[2rem] border-none shadow-xl shadow-zinc-200 overflow-hidden flex flex-col h-full group hover:bg-zinc-800 transition-all duration-300",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-12 bg-white/10 flex items-center px-6 text-white/80 font-medium text-sm",
                    children: [
                        title,
                        icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ml-auto text-white/60",
                            children: icon
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                            lineNumber: 81,
                            columnNumber: 30
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                    lineNumber: 79,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 flex flex-col justify-between flex-grow",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-4xl font-bold text-white tracking-tight",
                                children: value
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 85,
                                columnNumber: 25
                            }, this),
                            description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-white/60 text-xs font-medium uppercase tracking-wider",
                                children: description
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 87,
                                columnNumber: 29
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                        lineNumber: 84,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                    lineNumber: 83,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
            lineNumber: 78,
            columnNumber: 13
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-[2rem] border border-zinc-200 shadow-sm overflow-hidden flex flex-col h-full group hover:shadow-md transition-shadow duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `h-12 ${headerColor} flex items-center px-6 text-white font-medium text-sm`,
                children: [
                    title,
                    icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ml-auto opacity-80",
                        children: icon
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                        lineNumber: 101,
                        columnNumber: 26
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                lineNumber: 99,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-6 flex flex-col justify-between flex-grow",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-end gap-3 flex-wrap",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-3xl font-bold text-zinc-900 tracking-tight",
                                children: value
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 105,
                                columnNumber: 21
                            }, this),
                            change && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `mb-1 px-3 py-1 rounded-full text-[0.65rem] font-bold uppercase tracking-wider ${change.startsWith('-') ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`,
                                children: [
                                    change.startsWith('-') ? '' : '+',
                                    change,
                                    "% vs ayer"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                                lineNumber: 107,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                        lineNumber: 104,
                        columnNumber: 17
                    }, this),
                    description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-zinc-400 text-[0.7rem] font-medium uppercase tracking-widest mt-2",
                        children: description
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                        lineNumber: 114,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
                lineNumber: 103,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx",
        lineNumber: 98,
        columnNumber: 9
    }, this);
}
_c = DashboardMetricCard;
var _c;
__turbopack_context__.k.register(_c, "DashboardMetricCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/admin/dashboard/data:a10797 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDashboardMetrics",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"00083756b6dd13b63b3e33d85150476c9c2e49fdfe":"getDashboardMetrics"},"src/app/admin/dashboard/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("00083756b6dd13b63b3e33d85150476c9c2e49fdfe", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getDashboardMetrics");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcclxuXHJcbmltcG9ydCB7IHByaXNtYSB9IGZyb20gXCJAL2xpYi9wcmlzbWFcIjtcclxuaW1wb3J0IHsgc3RhcnRPZkRheSwgZW5kT2ZEYXksIHN1YkRheXMsIHN0YXJ0T2ZNb250aCwgZW5kT2ZNb250aCwgZm9ybWF0IH0gZnJvbSBcImRhdGUtZm5zXCI7XHJcbmltcG9ydCB7IGVzIH0gZnJvbSBcImRhdGUtZm5zL2xvY2FsZVwiO1xyXG5pbXBvcnQgeyBnZXRDb25maWdzIH0gZnJvbSBcIkAvYXBwL2FjdGlvbnMvY29uZmlnQWN0aW9uc1wiO1xyXG5pbXBvcnQgeyByZXF1aXJlQWRtaW4gfSBmcm9tIFwiQC9saWIvc2VydmVyQXV0aFwiO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldERhc2hib2FyZE1ldHJpY3MoKSB7XHJcbiAgICAvLyBGLTA0Yzogc2Vuc2l0aXZlIGZpbmFuY2lhbCBtZXRyaWNzIOKAlCBBRE1JTiBvbmx5XHJcbiAgICBhd2FpdCByZXF1aXJlQWRtaW4oKTtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGNvbnN0IHN0YXJ0T2ZUb2RheSA9IHN0YXJ0T2ZEYXkodG9kYXkpO1xyXG4gICAgICAgIGNvbnN0IGVuZE9mVG9kYXkgPSBlbmRPZkRheSh0b2RheSk7XHJcbiAgICAgICAgY29uc3Qgc3RhcnRPZlllc3RlcmRheSA9IHN0YXJ0T2ZEYXkoc3ViRGF5cyh0b2RheSwgMSkpO1xyXG4gICAgICAgIGNvbnN0IGVuZE9mWWVzdGVyZGF5ID0gZW5kT2ZEYXkoc3ViRGF5cyh0b2RheSwgMSkpO1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRNb250aFN0YXJ0ID0gc3RhcnRPZk1vbnRoKHRvZGF5KTtcclxuICAgICAgICBjb25zdCBjdXJyZW50TW9udGhFbmQgPSBlbmRPZk1vbnRoKHRvZGF5KTtcclxuXHJcbiAgICAgICAgLy8gRi0xMjogQWxsIGFnZ3JlZ2F0aW9ucyBwdXNoZWQgdG8gREIg4oCUIHJ1biBjb25jdXJyZW50bHkgdmlhIFByb21pc2UuYWxsXHJcbiAgICAgICAgLy8gUHJldmlvdXNseTogcHJpc21hLm9yZGVyLmZpbmRNYW55KHsgZXN0YWRvOkZJTkFMSVpBRE8gfSkg4oaSIGZpbHRlciArIHJlZHVjZSBpbiBKUyAobG9hZHMgQUxMIHJvd3MpXHJcbiAgICAgICAgLy8gTm93OiA4IHRhcmdldGVkIGFnZ3JlZ2F0ZSBxdWVyaWVzLCB6ZXJvIHJvd3MgdHJhbnNmZXJyZWQgdG8gTm9kZS5qc1xyXG4gICAgICAgIGNvbnN0IFtcclxuICAgICAgICAgICAgdG90YWxTYWxlc1Jlc3VsdCxcclxuICAgICAgICAgICAgc2FsZXNUb2RheVJlc3VsdCxcclxuICAgICAgICAgICAgc2FsZXNZZXN0ZXJkYXlSZXN1bHQsXHJcbiAgICAgICAgICAgIGN1cnJlbnRNb250aFNhbGVzUmVzdWx0LFxyXG4gICAgICAgICAgICB0b3RhbE9yZGVyc1RvZGF5LFxyXG4gICAgICAgICAgICBwZW5kaW5nT3JkZXJzLFxyXG4gICAgICAgICAgICBhY3RpdmVDdXN0b21lcnMsXHJcbiAgICAgICAgICAgIGNvbmZpZ3NSZXN1bHQsXHJcbiAgICAgICAgXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgLy8gQWxsLXRpbWUgdG90YWwgcmV2ZW51ZTogYmFzZWQgb24gcGF5bWVudCBzdGF0dXMgb25seVxyXG4gICAgICAgICAgICBwcmlzbWEub3JkZXIuYWdncmVnYXRlKHtcclxuICAgICAgICAgICAgICAgIF9zdW06IHsgdG90YWw6IHRydWUgfSxcclxuICAgICAgICAgICAgICAgIHdoZXJlOiB7IGNvYnJhZG86IHRydWUsIGVzdGFkbzogeyBub3Q6ICdDQU5DRUxBRE8nIH0sIGRlbGV0ZWRBdDogbnVsbCB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gVG9kYXkncyByZXZlbnVlOiBvcmRlcnMgcGFpZCB0b2RheVxyXG4gICAgICAgICAgICBwcmlzbWEub3JkZXIuYWdncmVnYXRlKHtcclxuICAgICAgICAgICAgICAgIF9zdW06IHsgdG90YWw6IHRydWUgfSxcclxuICAgICAgICAgICAgICAgIHdoZXJlOiB7IGNvYnJhZG86IHRydWUsIGVzdGFkbzogeyBub3Q6ICdDQU5DRUxBRE8nIH0sIGRlbGV0ZWRBdDogbnVsbCwgY29icmFkb0VuOiB7IGd0ZTogc3RhcnRPZlRvZGF5LCBsdGU6IGVuZE9mVG9kYXkgfSB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gWWVzdGVyZGF5J3MgcmV2ZW51ZTogb3JkZXJzIHBhaWQgeWVzdGVyZGF5XHJcbiAgICAgICAgICAgIHByaXNtYS5vcmRlci5hZ2dyZWdhdGUoe1xyXG4gICAgICAgICAgICAgICAgX3N1bTogeyB0b3RhbDogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgY29icmFkbzogdHJ1ZSwgZXN0YWRvOiB7IG5vdDogJ0NBTkNFTEFETycgfSwgZGVsZXRlZEF0OiBudWxsLCBjb2JyYWRvRW46IHsgZ3RlOiBzdGFydE9mWWVzdGVyZGF5LCBsdGU6IGVuZE9mWWVzdGVyZGF5IH0gfSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIC8vIEN1cnJlbnQgbW9udGgncyByZXZlbnVlOiBvcmRlcnMgcGFpZCB0aGlzIG1vbnRoXHJcbiAgICAgICAgICAgIHByaXNtYS5vcmRlci5hZ2dyZWdhdGUoe1xyXG4gICAgICAgICAgICAgICAgX3N1bTogeyB0b3RhbDogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgY29icmFkbzogdHJ1ZSwgZXN0YWRvOiB7IG5vdDogJ0NBTkNFTEFETycgfSwgZGVsZXRlZEF0OiBudWxsLCBjb2JyYWRvRW46IHsgZ3RlOiBjdXJyZW50TW9udGhTdGFydCwgbHRlOiBjdXJyZW50TW9udGhFbmQgfSB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gT3JkZXJzIHJlY2VpdmVkIHRvZGF5IChhbnkgc3RhdGUgZXhjZXB0IGRlbGV0ZWQpXHJcbiAgICAgICAgICAgIHByaXNtYS5vcmRlci5jb3VudCh7XHJcbiAgICAgICAgICAgICAgICB3aGVyZTogeyByZWNpYmlkb0VuOiB7IGd0ZTogc3RhcnRPZlRvZGF5LCBsdGU6IGVuZE9mVG9kYXkgfSwgZGVsZXRlZEF0OiBudWxsIH0sXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAvLyBBY3RpdmUgKG5vbi1maW5hbGl6ZWQsIG5vbi1jYW5jZWxsZWQpIG9yZGVyc1xyXG4gICAgICAgICAgICBwcmlzbWEub3JkZXIuY291bnQoe1xyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgZXN0YWRvOiB7IGluOiBbJ1JFQ0lCSURPJywgJ1BFTkRJRU5URScsICdFTl9QUkVQQVJBQ0lPTiddIH0sIGRlbGV0ZWRBdDogbnVsbCB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gQWN0aXZlIGN1c3RvbWVyc1xyXG4gICAgICAgICAgICBwcmlzbWEuY3VzdG9tZXIuY291bnQoeyB3aGVyZTogeyBhY3Rpdm86IHRydWUsIGRlbGV0ZWRBdDogbnVsbCB9IH0pLFxyXG4gICAgICAgICAgICAvLyBNb250aGx5IGdvYWwgY29uZmlnXHJcbiAgICAgICAgICAgIGdldENvbmZpZ3MoWydnb2Fscy5tb250aGx5J10pLFxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBjb25zdCB0b3RhbFNhbGVzID0gTnVtYmVyKHRvdGFsU2FsZXNSZXN1bHQuX3N1bS50b3RhbCA/PyAwKTtcclxuICAgICAgICBjb25zdCBzYWxlc1RvZGF5ID0gTnVtYmVyKHNhbGVzVG9kYXlSZXN1bHQuX3N1bS50b3RhbCA/PyAwKTtcclxuICAgICAgICBjb25zdCBzYWxlc1llc3RlcmRheSA9IE51bWJlcihzYWxlc1llc3RlcmRheVJlc3VsdC5fc3VtLnRvdGFsID8/IDApO1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRNb250aFNhbGVzID0gTnVtYmVyKGN1cnJlbnRNb250aFNhbGVzUmVzdWx0Ll9zdW0udG90YWwgPz8gMCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHNhbGVzR3Jvd3RoID0gc2FsZXNZZXN0ZXJkYXkgPiAwXHJcbiAgICAgICAgICAgID8gKChzYWxlc1RvZGF5IC0gc2FsZXNZZXN0ZXJkYXkpIC8gc2FsZXNZZXN0ZXJkYXkpICogMTAwXHJcbiAgICAgICAgICAgIDogc2FsZXNUb2RheSA+IDAgPyAxMDAgOiAwO1xyXG5cclxuICAgICAgICAvLyBNb250aGx5IGdvYWxcclxuICAgICAgICBsZXQgbW9udGhseUdvYWxTZXR0aW5nID0geyBhbW91bnQ6IDEwMDAwMDAsIHR5cGU6ICdyZXZlbnVlJyB9O1xyXG4gICAgICAgIGlmIChjb25maWdzUmVzdWx0LnN1Y2Nlc3MgJiYgY29uZmlnc1Jlc3VsdC5kYXRhPy5bJ2dvYWxzLm1vbnRobHknXSkge1xyXG4gICAgICAgICAgICBtb250aGx5R29hbFNldHRpbmcgPSBjb25maWdzUmVzdWx0LmRhdGFbJ2dvYWxzLm1vbnRobHknXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgeyBhbW91bnQ6IG1vbnRobHlHb2FsQW1vdW50LCB0eXBlOiBtb250aGx5R29hbFR5cGUgfSA9IG1vbnRobHlHb2FsU2V0dGluZztcclxuXHJcbiAgICAgICAgbGV0IGN1cnJlbnRBbW91bnQgPSBjdXJyZW50TW9udGhTYWxlcztcclxuICAgICAgICBpZiAobW9udGhseUdvYWxUeXBlID09PSAncHJvZml0Jykge1xyXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50TW9udGhFZ3Jlc29zID0gYXdhaXQgcHJpc21hLmVncmVzby5hZ2dyZWdhdGUoe1xyXG4gICAgICAgICAgICAgICAgX3N1bTogeyBtb250bzogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgZmVjaGE6IHsgZ3RlOiBjdXJyZW50TW9udGhTdGFydCwgbHRlOiBjdXJyZW50TW9udGhFbmQgfSwgZGVsZXRlZEF0OiBudWxsIH0sXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBjdXJyZW50QW1vdW50ID0gY3VycmVudE1vbnRoU2FsZXMgLSBOdW1iZXIoY3VycmVudE1vbnRoRWdyZXNvcy5fc3VtLm1vbnRvID8/IDApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgZ29hbFByb2dyZXNzID0gbW9udGhseUdvYWxBbW91bnQgPiAwXHJcbiAgICAgICAgICAgID8gTWF0aC5taW4oTWF0aC5yb3VuZCgoY3VycmVudEFtb3VudCAvIG1vbnRobHlHb2FsQW1vdW50KSAqIDEwMCksIDEwMClcclxuICAgICAgICAgICAgOiAwO1xyXG5cclxuICAgICAgICAvLyBXZWVrbHkgcmV2ZW51ZTogNyBpbmRpdmlkdWFsIGRheSBhZ2dyZWdhdGVzIGluIHBhcmFsbGVsXHJcbiAgICAgICAgY29uc3QgbGFzdDdEYXlzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogNyB9LCAoXywgaSkgPT4gc3ViRGF5cyh0b2RheSwgNiAtIGkpKTtcclxuICAgICAgICBjb25zdCB3ZWVrbHlBZ2dyZWdhdGVzID0gYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICAgIGxhc3Q3RGF5cy5tYXAoZGF0ZSA9PlxyXG4gICAgICAgICAgICAgICAgcHJpc21hLm9yZGVyLmFnZ3JlZ2F0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgX3N1bTogeyB0b3RhbDogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvYnJhZG86IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVzdGFkbzogeyBub3Q6ICdDQU5DRUxBRE8nIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZWRBdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29icmFkb0VuOiB7IGd0ZTogc3RhcnRPZkRheShkYXRlKSwgbHRlOiBlbmRPZkRheShkYXRlKSB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zdCB3ZWVrbHlSZXZlbnVlRGF0YSA9IGxhc3Q3RGF5cy5tYXAoKGRhdGUsIGkpID0+ICh7XHJcbiAgICAgICAgICAgIGRheTogZm9ybWF0KGRhdGUsICdlZWUnLCB7IGxvY2FsZTogZXMgfSkuc3Vic3RyaW5nKDAsIDMpLnRvVXBwZXJDYXNlKCksXHJcbiAgICAgICAgICAgIHJldmVudWU6IE51bWJlcih3ZWVrbHlBZ2dyZWdhdGVzW2ldLl9zdW0udG90YWwgPz8gMCksXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxyXG4gICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICB0b3RhbFNhbGVzLFxyXG4gICAgICAgICAgICAgICAgc2FsZXNUb2RheSxcclxuICAgICAgICAgICAgICAgIHNhbGVzR3Jvd3RoOiBzYWxlc0dyb3d0aC50b0ZpeGVkKDEpLFxyXG4gICAgICAgICAgICAgICAgdG90YWxPcmRlcnNUb2RheSxcclxuICAgICAgICAgICAgICAgIHBlbmRpbmdPcmRlcnMsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVDdXN0b21lcnMsXHJcbiAgICAgICAgICAgICAgICBtb250aGx5R29hbDogeyBhbW91bnQ6IG1vbnRobHlHb2FsQW1vdW50LCB0eXBlOiBtb250aGx5R29hbFR5cGUsIGN1cnJlbnRBbW91bnQsIHByb2dyZXNzOiBnb2FsUHJvZ3Jlc3MgfSxcclxuICAgICAgICAgICAgICAgIHdlZWtseVJldmVudWU6IHdlZWtseVJldmVudWVEYXRhLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZGFzaGJvYXJkIG1ldHJpY3M6JywgZXJyb3IpO1xyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0Vycm9yIGFsIGNhcmdhciBtw6l0cmljYXMnIH07XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWNlbnRBY3Rpdml0eSgpIHtcclxuICAgIC8vIEYtMDRjOiBvcmRlciBkYXRhIHdpdGggY3VzdG9tZXIgaW5mbyDigJQgQURNSU4gb25seVxyXG4gICAgYXdhaXQgcmVxdWlyZUFkbWluKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlY2VudE9yZGVycyA9IGF3YWl0IHByaXNtYS5vcmRlci5maW5kTWFueSh7XHJcbiAgICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgICAgICBkZWxldGVkQXQ6IG51bGxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGFrZTogNixcclxuICAgICAgICAgICAgb3JkZXJCeToge1xyXG4gICAgICAgICAgICAgICAgcmVjaWJpZG9FbjogJ2Rlc2MnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNlbGVjdDoge1xyXG4gICAgICAgICAgICAgICAgaWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBudW1lcm86IHRydWUsXHJcbiAgICAgICAgICAgICAgICBjbGllbnRlTm9tYnJlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgdG90YWw6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBlc3RhZG86IHRydWUsXHJcbiAgICAgICAgICAgICAgICByZWNpYmlkb0VuOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgaXRlbXM6IHtcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3Q6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbm9tYnJlUHJvZHVjdDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FudGlkYWQ6IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgICAgICAgZGF0YTogSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShyZWNlbnRPcmRlcnMpKVxyXG4gICAgICAgIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZWNlbnQgYWN0aXZpdHk6XCIsIGVycm9yKTtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgYWwgY2FyZ2FyIGFjdGl2aWRhZCByZWNpZW50ZVwiIH07XHJcbiAgICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiIwU0FRc0IsZ01BQUEifQ==
}),
"[project]/src/app/admin/dashboard/data:0d57b3 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getRecentActivity",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"00832637cc95d952fe63cf82e527add59537de41cf":"getRecentActivity"},"src/app/admin/dashboard/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("00832637cc95d952fe63cf82e527add59537de41cf", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getRecentActivity");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcclxuXHJcbmltcG9ydCB7IHByaXNtYSB9IGZyb20gXCJAL2xpYi9wcmlzbWFcIjtcclxuaW1wb3J0IHsgc3RhcnRPZkRheSwgZW5kT2ZEYXksIHN1YkRheXMsIHN0YXJ0T2ZNb250aCwgZW5kT2ZNb250aCwgZm9ybWF0IH0gZnJvbSBcImRhdGUtZm5zXCI7XHJcbmltcG9ydCB7IGVzIH0gZnJvbSBcImRhdGUtZm5zL2xvY2FsZVwiO1xyXG5pbXBvcnQgeyBnZXRDb25maWdzIH0gZnJvbSBcIkAvYXBwL2FjdGlvbnMvY29uZmlnQWN0aW9uc1wiO1xyXG5pbXBvcnQgeyByZXF1aXJlQWRtaW4gfSBmcm9tIFwiQC9saWIvc2VydmVyQXV0aFwiO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldERhc2hib2FyZE1ldHJpY3MoKSB7XHJcbiAgICAvLyBGLTA0Yzogc2Vuc2l0aXZlIGZpbmFuY2lhbCBtZXRyaWNzIOKAlCBBRE1JTiBvbmx5XHJcbiAgICBhd2FpdCByZXF1aXJlQWRtaW4oKTtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGNvbnN0IHN0YXJ0T2ZUb2RheSA9IHN0YXJ0T2ZEYXkodG9kYXkpO1xyXG4gICAgICAgIGNvbnN0IGVuZE9mVG9kYXkgPSBlbmRPZkRheSh0b2RheSk7XHJcbiAgICAgICAgY29uc3Qgc3RhcnRPZlllc3RlcmRheSA9IHN0YXJ0T2ZEYXkoc3ViRGF5cyh0b2RheSwgMSkpO1xyXG4gICAgICAgIGNvbnN0IGVuZE9mWWVzdGVyZGF5ID0gZW5kT2ZEYXkoc3ViRGF5cyh0b2RheSwgMSkpO1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRNb250aFN0YXJ0ID0gc3RhcnRPZk1vbnRoKHRvZGF5KTtcclxuICAgICAgICBjb25zdCBjdXJyZW50TW9udGhFbmQgPSBlbmRPZk1vbnRoKHRvZGF5KTtcclxuXHJcbiAgICAgICAgLy8gRi0xMjogQWxsIGFnZ3JlZ2F0aW9ucyBwdXNoZWQgdG8gREIg4oCUIHJ1biBjb25jdXJyZW50bHkgdmlhIFByb21pc2UuYWxsXHJcbiAgICAgICAgLy8gUHJldmlvdXNseTogcHJpc21hLm9yZGVyLmZpbmRNYW55KHsgZXN0YWRvOkZJTkFMSVpBRE8gfSkg4oaSIGZpbHRlciArIHJlZHVjZSBpbiBKUyAobG9hZHMgQUxMIHJvd3MpXHJcbiAgICAgICAgLy8gTm93OiA4IHRhcmdldGVkIGFnZ3JlZ2F0ZSBxdWVyaWVzLCB6ZXJvIHJvd3MgdHJhbnNmZXJyZWQgdG8gTm9kZS5qc1xyXG4gICAgICAgIGNvbnN0IFtcclxuICAgICAgICAgICAgdG90YWxTYWxlc1Jlc3VsdCxcclxuICAgICAgICAgICAgc2FsZXNUb2RheVJlc3VsdCxcclxuICAgICAgICAgICAgc2FsZXNZZXN0ZXJkYXlSZXN1bHQsXHJcbiAgICAgICAgICAgIGN1cnJlbnRNb250aFNhbGVzUmVzdWx0LFxyXG4gICAgICAgICAgICB0b3RhbE9yZGVyc1RvZGF5LFxyXG4gICAgICAgICAgICBwZW5kaW5nT3JkZXJzLFxyXG4gICAgICAgICAgICBhY3RpdmVDdXN0b21lcnMsXHJcbiAgICAgICAgICAgIGNvbmZpZ3NSZXN1bHQsXHJcbiAgICAgICAgXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgLy8gQWxsLXRpbWUgdG90YWwgcmV2ZW51ZTogYmFzZWQgb24gcGF5bWVudCBzdGF0dXMgb25seVxyXG4gICAgICAgICAgICBwcmlzbWEub3JkZXIuYWdncmVnYXRlKHtcclxuICAgICAgICAgICAgICAgIF9zdW06IHsgdG90YWw6IHRydWUgfSxcclxuICAgICAgICAgICAgICAgIHdoZXJlOiB7IGNvYnJhZG86IHRydWUsIGVzdGFkbzogeyBub3Q6ICdDQU5DRUxBRE8nIH0sIGRlbGV0ZWRBdDogbnVsbCB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gVG9kYXkncyByZXZlbnVlOiBvcmRlcnMgcGFpZCB0b2RheVxyXG4gICAgICAgICAgICBwcmlzbWEub3JkZXIuYWdncmVnYXRlKHtcclxuICAgICAgICAgICAgICAgIF9zdW06IHsgdG90YWw6IHRydWUgfSxcclxuICAgICAgICAgICAgICAgIHdoZXJlOiB7IGNvYnJhZG86IHRydWUsIGVzdGFkbzogeyBub3Q6ICdDQU5DRUxBRE8nIH0sIGRlbGV0ZWRBdDogbnVsbCwgY29icmFkb0VuOiB7IGd0ZTogc3RhcnRPZlRvZGF5LCBsdGU6IGVuZE9mVG9kYXkgfSB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gWWVzdGVyZGF5J3MgcmV2ZW51ZTogb3JkZXJzIHBhaWQgeWVzdGVyZGF5XHJcbiAgICAgICAgICAgIHByaXNtYS5vcmRlci5hZ2dyZWdhdGUoe1xyXG4gICAgICAgICAgICAgICAgX3N1bTogeyB0b3RhbDogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgY29icmFkbzogdHJ1ZSwgZXN0YWRvOiB7IG5vdDogJ0NBTkNFTEFETycgfSwgZGVsZXRlZEF0OiBudWxsLCBjb2JyYWRvRW46IHsgZ3RlOiBzdGFydE9mWWVzdGVyZGF5LCBsdGU6IGVuZE9mWWVzdGVyZGF5IH0gfSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIC8vIEN1cnJlbnQgbW9udGgncyByZXZlbnVlOiBvcmRlcnMgcGFpZCB0aGlzIG1vbnRoXHJcbiAgICAgICAgICAgIHByaXNtYS5vcmRlci5hZ2dyZWdhdGUoe1xyXG4gICAgICAgICAgICAgICAgX3N1bTogeyB0b3RhbDogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgY29icmFkbzogdHJ1ZSwgZXN0YWRvOiB7IG5vdDogJ0NBTkNFTEFETycgfSwgZGVsZXRlZEF0OiBudWxsLCBjb2JyYWRvRW46IHsgZ3RlOiBjdXJyZW50TW9udGhTdGFydCwgbHRlOiBjdXJyZW50TW9udGhFbmQgfSB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gT3JkZXJzIHJlY2VpdmVkIHRvZGF5IChhbnkgc3RhdGUgZXhjZXB0IGRlbGV0ZWQpXHJcbiAgICAgICAgICAgIHByaXNtYS5vcmRlci5jb3VudCh7XHJcbiAgICAgICAgICAgICAgICB3aGVyZTogeyByZWNpYmlkb0VuOiB7IGd0ZTogc3RhcnRPZlRvZGF5LCBsdGU6IGVuZE9mVG9kYXkgfSwgZGVsZXRlZEF0OiBudWxsIH0sXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAvLyBBY3RpdmUgKG5vbi1maW5hbGl6ZWQsIG5vbi1jYW5jZWxsZWQpIG9yZGVyc1xyXG4gICAgICAgICAgICBwcmlzbWEub3JkZXIuY291bnQoe1xyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgZXN0YWRvOiB7IGluOiBbJ1JFQ0lCSURPJywgJ1BFTkRJRU5URScsICdFTl9QUkVQQVJBQ0lPTiddIH0sIGRlbGV0ZWRBdDogbnVsbCB9LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gQWN0aXZlIGN1c3RvbWVyc1xyXG4gICAgICAgICAgICBwcmlzbWEuY3VzdG9tZXIuY291bnQoeyB3aGVyZTogeyBhY3Rpdm86IHRydWUsIGRlbGV0ZWRBdDogbnVsbCB9IH0pLFxyXG4gICAgICAgICAgICAvLyBNb250aGx5IGdvYWwgY29uZmlnXHJcbiAgICAgICAgICAgIGdldENvbmZpZ3MoWydnb2Fscy5tb250aGx5J10pLFxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBjb25zdCB0b3RhbFNhbGVzID0gTnVtYmVyKHRvdGFsU2FsZXNSZXN1bHQuX3N1bS50b3RhbCA/PyAwKTtcclxuICAgICAgICBjb25zdCBzYWxlc1RvZGF5ID0gTnVtYmVyKHNhbGVzVG9kYXlSZXN1bHQuX3N1bS50b3RhbCA/PyAwKTtcclxuICAgICAgICBjb25zdCBzYWxlc1llc3RlcmRheSA9IE51bWJlcihzYWxlc1llc3RlcmRheVJlc3VsdC5fc3VtLnRvdGFsID8/IDApO1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRNb250aFNhbGVzID0gTnVtYmVyKGN1cnJlbnRNb250aFNhbGVzUmVzdWx0Ll9zdW0udG90YWwgPz8gMCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHNhbGVzR3Jvd3RoID0gc2FsZXNZZXN0ZXJkYXkgPiAwXHJcbiAgICAgICAgICAgID8gKChzYWxlc1RvZGF5IC0gc2FsZXNZZXN0ZXJkYXkpIC8gc2FsZXNZZXN0ZXJkYXkpICogMTAwXHJcbiAgICAgICAgICAgIDogc2FsZXNUb2RheSA+IDAgPyAxMDAgOiAwO1xyXG5cclxuICAgICAgICAvLyBNb250aGx5IGdvYWxcclxuICAgICAgICBsZXQgbW9udGhseUdvYWxTZXR0aW5nID0geyBhbW91bnQ6IDEwMDAwMDAsIHR5cGU6ICdyZXZlbnVlJyB9O1xyXG4gICAgICAgIGlmIChjb25maWdzUmVzdWx0LnN1Y2Nlc3MgJiYgY29uZmlnc1Jlc3VsdC5kYXRhPy5bJ2dvYWxzLm1vbnRobHknXSkge1xyXG4gICAgICAgICAgICBtb250aGx5R29hbFNldHRpbmcgPSBjb25maWdzUmVzdWx0LmRhdGFbJ2dvYWxzLm1vbnRobHknXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgeyBhbW91bnQ6IG1vbnRobHlHb2FsQW1vdW50LCB0eXBlOiBtb250aGx5R29hbFR5cGUgfSA9IG1vbnRobHlHb2FsU2V0dGluZztcclxuXHJcbiAgICAgICAgbGV0IGN1cnJlbnRBbW91bnQgPSBjdXJyZW50TW9udGhTYWxlcztcclxuICAgICAgICBpZiAobW9udGhseUdvYWxUeXBlID09PSAncHJvZml0Jykge1xyXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50TW9udGhFZ3Jlc29zID0gYXdhaXQgcHJpc21hLmVncmVzby5hZ2dyZWdhdGUoe1xyXG4gICAgICAgICAgICAgICAgX3N1bTogeyBtb250bzogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgd2hlcmU6IHsgZmVjaGE6IHsgZ3RlOiBjdXJyZW50TW9udGhTdGFydCwgbHRlOiBjdXJyZW50TW9udGhFbmQgfSwgZGVsZXRlZEF0OiBudWxsIH0sXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBjdXJyZW50QW1vdW50ID0gY3VycmVudE1vbnRoU2FsZXMgLSBOdW1iZXIoY3VycmVudE1vbnRoRWdyZXNvcy5fc3VtLm1vbnRvID8/IDApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgZ29hbFByb2dyZXNzID0gbW9udGhseUdvYWxBbW91bnQgPiAwXHJcbiAgICAgICAgICAgID8gTWF0aC5taW4oTWF0aC5yb3VuZCgoY3VycmVudEFtb3VudCAvIG1vbnRobHlHb2FsQW1vdW50KSAqIDEwMCksIDEwMClcclxuICAgICAgICAgICAgOiAwO1xyXG5cclxuICAgICAgICAvLyBXZWVrbHkgcmV2ZW51ZTogNyBpbmRpdmlkdWFsIGRheSBhZ2dyZWdhdGVzIGluIHBhcmFsbGVsXHJcbiAgICAgICAgY29uc3QgbGFzdDdEYXlzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogNyB9LCAoXywgaSkgPT4gc3ViRGF5cyh0b2RheSwgNiAtIGkpKTtcclxuICAgICAgICBjb25zdCB3ZWVrbHlBZ2dyZWdhdGVzID0gYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICAgIGxhc3Q3RGF5cy5tYXAoZGF0ZSA9PlxyXG4gICAgICAgICAgICAgICAgcHJpc21hLm9yZGVyLmFnZ3JlZ2F0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgX3N1bTogeyB0b3RhbDogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvYnJhZG86IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVzdGFkbzogeyBub3Q6ICdDQU5DRUxBRE8nIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZWRBdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29icmFkb0VuOiB7IGd0ZTogc3RhcnRPZkRheShkYXRlKSwgbHRlOiBlbmRPZkRheShkYXRlKSB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zdCB3ZWVrbHlSZXZlbnVlRGF0YSA9IGxhc3Q3RGF5cy5tYXAoKGRhdGUsIGkpID0+ICh7XHJcbiAgICAgICAgICAgIGRheTogZm9ybWF0KGRhdGUsICdlZWUnLCB7IGxvY2FsZTogZXMgfSkuc3Vic3RyaW5nKDAsIDMpLnRvVXBwZXJDYXNlKCksXHJcbiAgICAgICAgICAgIHJldmVudWU6IE51bWJlcih3ZWVrbHlBZ2dyZWdhdGVzW2ldLl9zdW0udG90YWwgPz8gMCksXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxyXG4gICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICB0b3RhbFNhbGVzLFxyXG4gICAgICAgICAgICAgICAgc2FsZXNUb2RheSxcclxuICAgICAgICAgICAgICAgIHNhbGVzR3Jvd3RoOiBzYWxlc0dyb3d0aC50b0ZpeGVkKDEpLFxyXG4gICAgICAgICAgICAgICAgdG90YWxPcmRlcnNUb2RheSxcclxuICAgICAgICAgICAgICAgIHBlbmRpbmdPcmRlcnMsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVDdXN0b21lcnMsXHJcbiAgICAgICAgICAgICAgICBtb250aGx5R29hbDogeyBhbW91bnQ6IG1vbnRobHlHb2FsQW1vdW50LCB0eXBlOiBtb250aGx5R29hbFR5cGUsIGN1cnJlbnRBbW91bnQsIHByb2dyZXNzOiBnb2FsUHJvZ3Jlc3MgfSxcclxuICAgICAgICAgICAgICAgIHdlZWtseVJldmVudWU6IHdlZWtseVJldmVudWVEYXRhLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZGFzaGJvYXJkIG1ldHJpY3M6JywgZXJyb3IpO1xyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0Vycm9yIGFsIGNhcmdhciBtw6l0cmljYXMnIH07XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWNlbnRBY3Rpdml0eSgpIHtcclxuICAgIC8vIEYtMDRjOiBvcmRlciBkYXRhIHdpdGggY3VzdG9tZXIgaW5mbyDigJQgQURNSU4gb25seVxyXG4gICAgYXdhaXQgcmVxdWlyZUFkbWluKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlY2VudE9yZGVycyA9IGF3YWl0IHByaXNtYS5vcmRlci5maW5kTWFueSh7XHJcbiAgICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgICAgICBkZWxldGVkQXQ6IG51bGxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGFrZTogNixcclxuICAgICAgICAgICAgb3JkZXJCeToge1xyXG4gICAgICAgICAgICAgICAgcmVjaWJpZG9FbjogJ2Rlc2MnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNlbGVjdDoge1xyXG4gICAgICAgICAgICAgICAgaWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBudW1lcm86IHRydWUsXHJcbiAgICAgICAgICAgICAgICBjbGllbnRlTm9tYnJlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgdG90YWw6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBlc3RhZG86IHRydWUsXHJcbiAgICAgICAgICAgICAgICByZWNpYmlkb0VuOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgaXRlbXM6IHtcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3Q6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbm9tYnJlUHJvZHVjdDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FudGlkYWQ6IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgICAgICAgZGF0YTogSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShyZWNlbnRPcmRlcnMpKVxyXG4gICAgICAgIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZWNlbnQgYWN0aXZpdHk6XCIsIGVycm9yKTtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgYWwgY2FyZ2FyIGFjdGl2aWRhZCByZWNpZW50ZVwiIH07XHJcbiAgICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJ3U0F1SXNCLDhMQUFBIn0=
}),
"[project]/src/components/ui/spectrum-icons.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SpectrumIcon",
    ()=>SpectrumIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function SpectrumIcon({ variant = "diamond", className, ...props }) {
    // Background Aesthetic Blobs
    if (variant === "organic") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 200 200",
            xmlns: "http://www.w3.org/2000/svg",
            className: className,
            ...props,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fill: "currentColor",
                d: "M44.7,-76.4C58.8,-69.2,71.8,-59.1,81.3,-46.6C90.8,-34.1,96.8,-19.1,97.7,-4C98.6,11.2,94.5,26.4,85.6,38.8C76.8,51.3,63.2,61.1,48.2,66.8C33.2,72.5,16.6,74.1,2.1,70.5C-12.4,66.8,-24.8,57.9,-37.8,49.9C-50.8,41.9,-64.4,34.8,-71.4,23.3C-78.4,11.8,-78.9,-4.1,-75.4,-18.9C-71.9,-33.7,-64.4,-47.4,-53.1,-56.3C-41.8,-65.3,-26.7,-69.5,-12.3,-72.1C2.1,-74.7,16.6,-75.6,30.6,-78.3C35.3,-79.1,40,-78.6,44.7,-76.4Z",
                transform: "translate(100 100)"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                lineNumber: 12,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/spectrum-icons.tsx",
            lineNumber: 11,
            columnNumber: 13
        }, this);
    }
    if (variant === "starburst") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 200 200",
            xmlns: "http://www.w3.org/2000/svg",
            className: className,
            ...props,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fill: "currentColor",
                d: "M100,5 C105,40 160,40 195,50 C160,60 160,110 195,150 C160,140 105,160 100,195 C95,160 40,140 5,150 C40,110 40,60 5,50 C40,40 95,40 100,5 Z"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                lineNumber: 20,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/spectrum-icons.tsx",
            lineNumber: 19,
            columnNumber: 13
        }, this);
    }
    if (variant === "blob") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 200 200",
            xmlns: "http://www.w3.org/2000/svg",
            className: className,
            ...props,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fill: "currentColor",
                d: "M51.1,-71.6C62.5,-61.1,65.3,-40.8,70.7,-21.9C76.2,-2.9,84.4,14.8,79.8,30C75.2,45.2,57.8,58,40.1,65.7C22.4,73.4,4.3,76.1,-13.6,74.5C-31.4,72.9,-49,67,-61.4,54.7C-73.8,42.4,-81,23.7,-82.1,5.1C-83.3,-13.5,-78.4,-31.9,-68,-46.3C-57.5,-60.7,-41.5,-71.1,-24.5,-75.1C-7.5,-79.1,10.6,-76.8,26.4,-70.7L51.1,-71.6Z",
                transform: "translate(100 100)"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                lineNumber: 28,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/spectrum-icons.tsx",
            lineNumber: 27,
            columnNumber: 13
        }, this);
    }
    // Stylized "Dollar/Revenue" equivalent
    if (variant === "diamond") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            className: className,
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12 2L2 12l10 10 10-10L12 2z"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 37,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12 2v20"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 38,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M2 12h20"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 39,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/spectrum-icons.tsx",
            lineNumber: 36,
            columnNumber: 13
        }, this);
    }
    // Stylized "Bag/Orders" equivalent
    if (variant === "cube") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            className: className,
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 48,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M3.27 6.96L12 12.01l8.73-5.05"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 49,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12 22.08V12"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 50,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/spectrum-icons.tsx",
            lineNumber: 47,
            columnNumber: 13
        }, this);
    }
    // Stylized "Users/Clients" equivalent
    if (variant === "nodes") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            className: className,
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "18",
                    cy: "6",
                    r: "3"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 59,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "6",
                    cy: "18",
                    r: "3"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 60,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "18",
                    cy: "18",
                    r: "3"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 61,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M16.5 7.5l-9 9"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 62,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M18 9v6"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 63,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M15 18H9"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                    lineNumber: 64,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/spectrum-icons.tsx",
            lineNumber: 58,
            columnNumber: 13
        }, this);
    }
    // Stylized "Trending/Growth" equivalent
    if (variant === "wave") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            className: className,
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...props,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M3 12h4l3-9 5 18 3-9h3"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/spectrum-icons.tsx",
                lineNumber: 73,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/spectrum-icons.tsx",
            lineNumber: 72,
            columnNumber: 13
        }, this);
    }
    return null;
}
_c = SpectrumIcon;
var _c;
__turbopack_context__.k.register(_c, "SpectrumIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/admin/dashboard/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-up-right.js [app-client] (ecmascript) <export default as ArrowUpRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shopping-basket.js [app-client] (ecmascript) <export default as ShoppingBasket>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$locale$2f$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/locale/es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$components$2f$DashboardMetricCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/admin/dashboard/components/DashboardMetricCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$data$3a$a10797__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/app/admin/dashboard/data:a10797 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$data$3a$0d57b3__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/app/admin/dashboard/data:0d57b3 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$spectrum$2d$icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/spectrum-icons.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function DashboardPage() {
    _s();
    const [metrics, setMetrics] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activity, setActivity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const fetchData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardPage.useCallback[fetchData]": async ()=>{
            setLoading(true);
            try {
                const [metricsRes, activityRes] = await Promise.all([
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$data$3a$a10797__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getDashboardMetrics"])(),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$data$3a$0d57b3__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getRecentActivity"])()
                ]);
                if (metricsRes.success) setMetrics(metricsRes.data);
                if (activityRes.success) setActivity(activityRes.data);
            } catch (error) {
                console.error("Dashboard load error:", error);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error al cargar datos del dashboard");
            } finally{
                setLoading(false);
            }
        }
    }["DashboardPage.useCallback[fetchData]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardPage.useEffect": ()=>{
            fetchData();
        }
    }["DashboardPage.useEffect"], [
        fetchData
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-6 animate-in fade-in duration-700",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row justify-between items-start md:items-end gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-4xl font-black text-zinc-900 tracking-tight",
                                children: "Panel de Control"
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                lineNumber: 90,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-zinc-500 mt-2 text-lg",
                                children: "Resumen operativo y financiero de hoy."
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                lineNumber: 91,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 89,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3 bg-white p-2 rounded-2xl border border-zinc-200 shadow-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-10 w-10 bg-zinc-900 rounded-xl flex items-center justify-center text-white",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                    size: 18
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                    lineNumber: 95,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                lineNumber: 94,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pr-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[0.65rem] font-bold text-zinc-400 uppercase tracking-widest",
                                        children: "Hoy"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                        lineNumber: 98,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-bold text-zinc-900",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(), "EEEE, dd 'de' MMMM", {
                                            locale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$locale$2f$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["es"]
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                        lineNumber: 99,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                lineNumber: 97,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 93,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                lineNumber: 88,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$components$2f$DashboardMetricCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DashboardMetricCard"], {
                        title: "Ventas de Hoy",
                        value: loading ? "..." : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatCurrency"])(metrics?.salesToday || 0),
                        change: metrics?.salesGrowth,
                        headerColor: "bg-zinc-900",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$spectrum$2d$icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpectrumIcon"], {
                            variant: "diamond",
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                            lineNumber: 111,
                            columnNumber: 27
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 106,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$components$2f$DashboardMetricCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DashboardMetricCard"], {
                        title: "Pedidos de Hoy",
                        value: loading ? "..." : metrics?.totalOrdersToday || 0,
                        description: `${metrics?.pendingOrders || 0} pendientes`,
                        headerColor: "bg-orange-500",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$spectrum$2d$icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpectrumIcon"], {
                            variant: "cube",
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                            lineNumber: 118,
                            columnNumber: 27
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 113,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$components$2f$DashboardMetricCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DashboardMetricCard"], {
                        title: "Clientes Activos",
                        value: loading ? "..." : metrics?.activeCustomers || 0,
                        headerColor: "bg-indigo-600",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$spectrum$2d$icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpectrumIcon"], {
                            variant: "nodes",
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                            lineNumber: 124,
                            columnNumber: 27
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 120,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$admin$2f$dashboard$2f$components$2f$DashboardMetricCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DashboardMetricCard"], {
                        isPrimary: true,
                        title: "Meta Mensual",
                        value: loading ? "..." : `${metrics?.monthlyGoal?.progress || 0}%`,
                        description: "Progreso del mes",
                        headerColor: "bg-emerald-600",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$spectrum$2d$icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpectrumIcon"], {
                            variant: "wave",
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                            lineNumber: 132,
                            columnNumber: 27
                        }, void 0),
                        monthlyGoal: metrics?.monthlyGoal
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 126,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                lineNumber: 105,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "lg:col-span-7 flex flex-col gap-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-white rounded-[2.5rem] border border-zinc-200 shadow-sm overflow-hidden flex flex-col h-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-8 border-b border-zinc-100 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-xl font-bold text-zinc-900 tracking-tight",
                                                    children: "Rendimiento Semanal"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 145,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-zinc-400 text-sm mt-1",
                                                    children: "Comparativa de ingresos diarios"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 146,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 144,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/admin/dashboard/reportes",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "outline",
                                                className: "rounded-full border-zinc-200 text-zinc-600 text-xs font-bold uppercase tracking-widest",
                                                children: "Ver Reporte Completo"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                lineNumber: 149,
                                                columnNumber: 33
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 148,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                    lineNumber: 143,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-8 flex-grow flex flex-col items-center justify-center bg-zinc-50/50",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-64 w-full flex items-end justify-between px-4 gap-2 sm:gap-4",
                                        children: metrics?.weeklyRevenue?.map((data, i)=>{
                                            const maxRevenue = Math.max(...metrics.weeklyRevenue.map((d)=>d.revenue) || [
                                                1
                                            ]);
                                            const heightPercentage = maxRevenue > 0 ? data.revenue / maxRevenue * 100 : 0;
                                            const finalHeight = data.revenue > 0 ? Math.max(5, heightPercentage) : 0;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col items-center flex-1 group",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-full h-52 flex items-end relative mb-3",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-full bg-zinc-200 rounded-xl group-hover:bg-zinc-900 transition-all duration-500 relative",
                                                            style: {
                                                                height: `${finalHeight}%`
                                                            },
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "absolute -top-10 left-1/2 -translate-x-1/2 bg-zinc-900 text-white text-[0.65rem] font-bold py-1 px-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap",
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatCurrency"])(data.revenue)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                lineNumber: 168,
                                                                columnNumber: 53
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                            lineNumber: 164,
                                                            columnNumber: 49
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                        lineNumber: 163,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[0.65rem] font-bold text-zinc-400 text-center uppercase tracking-widest shrink-0",
                                                        children: data.day
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                        lineNumber: 173,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                lineNumber: 162,
                                                columnNumber: 41
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                        lineNumber: 155,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                    lineNumber: 154,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-8 bg-zinc-900 text-white flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-12 w-12 bg-white/10 rounded-2xl flex items-center justify-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__["ArrowUpRight"], {
                                                        className: "text-emerald-400"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                        lineNumber: 184,
                                                        columnNumber: 37
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 183,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-white font-bold text-lg",
                                                            children: "Ventas Totales Históricas"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                            lineNumber: 187,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-white/50 text-xs uppercase tracking-widest font-medium",
                                                            children: "Desde el inicio del sistema"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                            lineNumber: 188,
                                                            columnNumber: 37
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 186,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 182,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-3xl font-black",
                                            children: loading ? "..." : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatCurrency"])(metrics?.totalSales || 0)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 191,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                    lineNumber: 181,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                            lineNumber: 142,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 141,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "lg:col-span-5",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-white rounded-[2.5rem] border border-zinc-200 shadow-sm overflow-hidden flex flex-col h-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-8 border-b border-zinc-100 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-xl font-bold text-zinc-900 tracking-tight",
                                                    children: "Últimos Pedidos"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 201,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-zinc-400 text-sm mt-1",
                                                    children: "Actividad en tiempo real"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 202,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 200,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/admin/dashboard/pedidos",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "ghost",
                                                size: "sm",
                                                className: "rounded-full h-10 w-10 p-0 hover:bg-zinc-100",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                    className: "h-5 w-5 text-zinc-400"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 206,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                lineNumber: 205,
                                                columnNumber: 33
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 204,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                    lineNumber: 199,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-6 space-y-4 flex-grow overflow-y-auto max-h-[500px]",
                                    children: loading ? Array.from({
                                        length: 5
                                    }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-4 p-4 rounded-3xl bg-zinc-50 animate-pulse",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-12 w-12 bg-zinc-100 rounded-2xl"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 215,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1 space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-4 bg-zinc-100 rounded w-1/2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                            lineNumber: 217,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-3 bg-zinc-100 rounded w-1/3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                            lineNumber: 218,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 216,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, i, true, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 214,
                                            columnNumber: 37
                                        }, this)) : activity.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col items-center justify-center py-12 text-center px-8",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-20 w-20 bg-zinc-50 rounded-full flex items-center justify-center mb-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__["ShoppingBasket"], {
                                                    size: 32,
                                                    className: "text-zinc-200"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 225,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                lineNumber: 224,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                className: "font-bold text-zinc-900",
                                                children: "Sin pedidos recientes"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                lineNumber: 227,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-zinc-500 text-sm mt-1",
                                                children: "Los nuevos pedidos aparecerán aquí automáticamente."
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                lineNumber: 228,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                        lineNumber: 223,
                                        columnNumber: 33
                                    }, this) : activity.map((order)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "group p-4 rounded-[1.75rem] border border-transparent hover:border-zinc-100 hover:bg-zinc-50/50 transition-all duration-300",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "h-14 w-14 rounded-2xl bg-zinc-900 text-white flex flex-col items-center justify-center shadow-lg shadow-zinc-200",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                                                size: 16,
                                                                className: "text-white/60 mb-1"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                lineNumber: 235,
                                                                columnNumber: 49
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[0.65rem] font-bold",
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(order.recibidoEn), "HH:mm")
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                lineNumber: 236,
                                                                columnNumber: 49
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                        lineNumber: 234,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex-1 overflow-hidden",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-baseline justify-between gap-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                        className: "font-bold text-zinc-900 truncate",
                                                                        children: order.clienteNombre || "Cliente General"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                        lineNumber: 240,
                                                                        columnNumber: 53
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "font-black text-zinc-900 whitespace-nowrap",
                                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatCurrency"])(Number(order.total))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                        lineNumber: 241,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                lineNumber: 239,
                                                                columnNumber: 49
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2 mt-1",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                                        className: `text-[0.6rem] font-black px-2 py-0 rounded-full border-none ${order.estado === 'FINALIZADO' ? 'bg-emerald-50 text-emerald-600' : order.estado === 'CANCELADO' ? 'bg-rose-50 text-rose-600' : 'bg-orange-50 text-orange-600'}`,
                                                                        children: order.estado
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                        lineNumber: 244,
                                                                        columnNumber: 53
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[0.7rem] text-zinc-400 font-medium tracking-tight truncate",
                                                                        children: [
                                                                            order.items?.length || 0,
                                                                            " ítems • ",
                                                                            order.numero
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                        lineNumber: 250,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                                lineNumber: 243,
                                                                columnNumber: 49
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                        lineNumber: 238,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                lineNumber: 233,
                                                columnNumber: 41
                                            }, this)
                                        }, order.id, false, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 232,
                                            columnNumber: 37
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                    lineNumber: 211,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-6 bg-zinc-50/50 border-t border-zinc-100",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/admin/dashboard/pedidos",
                                        className: "w-full",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            className: "w-full h-12 rounded-2xl bg-zinc-900 text-white hover:bg-zinc-800 shadow-lg shadow-zinc-200 transition-all font-bold group",
                                            children: [
                                                "Gestionar Todos los Pedidos",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                    size: 16,
                                                    className: "ml-2 group-hover:translate-x-1 transition-transform"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                                    lineNumber: 265,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                            lineNumber: 263,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                        lineNumber: 262,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/dashboard/page.tsx",
                                    lineNumber: 261,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/dashboard/page.tsx",
                            lineNumber: 198,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/dashboard/page.tsx",
                        lineNumber: 197,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/dashboard/page.tsx",
                lineNumber: 138,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/admin/dashboard/page.tsx",
        lineNumber: 86,
        columnNumber: 9
    }, this);
}
_s(DashboardPage, "lvj4UoUI0fqI8uwwOa54z1Jaw5s=");
_c = DashboardPage;
var _c;
__turbopack_context__.k.register(_c, "DashboardPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_fc26ff26._.js.map